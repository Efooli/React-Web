import React from 'react';
import { Provider } from 'react-redux';
import store from './Redux/Store';
import TodoList from './Components/TodoList';
import AddTodo from './Components/AddTodo';
import InfoIcon from './Components/InfoIcon';
import TodoCounter from './Components/TodoCounter';
import './App.css';

const App = () => {
  return (
    <Provider store={store}>
      <div className="app-container">
        <h1>Todo App</h1>
        <TodoList />
        <AddTodo />
       
        <InfoIcon />
        <TodoCounter />
      </div>
    </Provider>
  );
};

export default App;

