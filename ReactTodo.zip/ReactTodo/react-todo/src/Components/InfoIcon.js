import React, { useState } from 'react';

const InfoIcon = () => {
  // State to control the visibility of the popup
  const [showPopup, setShowPopup] = useState(false);

  // Function to toggle the visibility of the popup
  const togglePopup = () => {
    setShowPopup(!showPopup);
  };

  return (
    <div className="info-icon">
      {/* Icon triggering the popup on click */}
      <span onClick={togglePopup} style={{ cursor: 'pointer' }}>
        ℹ️
      </span>
      {/* Popup content displayed when showPopup is true */}
      {showPopup && (
        <div className="popup">
          {/* Popup instructions */}
          <p>Instructions:</p>
          <ul>
            <li>Click the checkbox to mark a todo as completed.</li>
            <li>Edit a todo by clicking the "Edit" button.</li>
            <li>Delete a todo using the "Delete" button.</li>
          </ul>
          {/* Button to close the popup */}
          <button onClick={togglePopup}>Close</button>
        </div>
      )}
    </div>
  );
};

export default InfoIcon;
