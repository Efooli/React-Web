import React, { useState, useEffect, useCallback } from 'react';
import { useDispatch } from 'react-redux';
import { addTodo } from '../Redux/Todos';

const AddTodo = () => {
  // State to track the new todo input value
  const [newTodo, setNewTodo] = useState('');
  // State to handle and display warning messages
  const [warningMessage, setWarningMessage] = useState('');
  // Redux dispatch function
  const dispatch = useDispatch();

  // Callback function to handle the addition of a new todo
  const handleAddTodo = useCallback(() => {
    // Check if the new todo is empty
    if (newTodo.trim() === '') {
      // Set a warning message if the todo is empty
      setWarningMessage('Todo cannot be empty!');
    } else {
      // Dispatch the addTodo action with the new todo content
      dispatch(addTodo(newTodo));
      // Clear the input and warning message on successful addition
      setNewTodo('');
      setWarningMessage('');
    }
  }, [dispatch, newTodo]);

  // Callback function to handle keypress events (Enter key)
  const handleKeyPress = useCallback(
    (e) => {
      // Check if the pressed key is Enter
      if (e.key === 'Enter') {
        // Call the handleAddTodo function on Enter key press
        handleAddTodo();
      }
    },
    [handleAddTodo]
  );

  // Effect to add and remove event listener for keypress events
  useEffect(() => {
    document.addEventListener('keypress', handleKeyPress);

    return () => {
      document.removeEventListener('keypress', handleKeyPress);
    };
  }, [handleKeyPress]);

  return (
    <div className="add-todo">
      {/* Input field for entering new todo */}
      <input
        type="text"
        value={newTodo}
        onChange={(e) => {
          // Update the newTodo state on input change
          setNewTodo(e.target.value);
          // Clear the warning message when typing
          setWarningMessage('');
        }}
      />
      {/* Display warning message if exists */}
      {warningMessage && <p style={{ color: 'red' }}>{warningMessage}</p>}
      {/* Button to add todo, calls handleAddTodo on click */}
      <button onClick={handleAddTodo}>Add Todo</button>
    </div>
  );
};

export default AddTodo;
