import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { deleteTodo, toggleTodo, editTodo } from '../Redux/Todos';
import '../Style/TodoItem.css';

const TodoItem = ({ todo, index }) => {
  // Retrieve the dispatch function from the Redux store
  const dispatch = useDispatch();

  // State to manage the editing mode of the todo item
  const [isEditing, setIsEditing] = useState(false);

  // State to manage the content of the edited todo
  const [editedTodo, setEditedTodo] = useState(todo.content);

  // Toggle the completion status of the todo when the checkbox is clicked
  const handleToggleComplete = () => {
    dispatch(toggleTodo(index));
  };

  // Delete the todo when the "Delete" button is clicked
  const handleDeleteTodo = () => {
    dispatch(deleteTodo(index));
  };

  // Enable the editing mode and set the editedTodo state to the current content
  const handleEditTodo = () => {
    setIsEditing(true);
    setEditedTodo(todo.content);
  };

  // Save the edited todo and exit the editing mode
  const handleSaveEdit = () => {
    // Check if the edited todo is not empty
    if (!editedTodo.trim()) {
      setIsEditing(false);
      return;
    }

    // Dispatch the editTodo action to update the todo content
    dispatch(editTodo(index, editedTodo));
    setIsEditing(false);
  };

  // Cancel the edit, exit the editing mode, and reset the editedTodo state
  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedTodo(todo.content);
  };

  // Update the editedTodo state when the input value changes
  const handleInputChange = (e) => {
    setEditedTodo(e.target.value);
  };

  // Render the todo item with appropriate styles and UI based on completion status and editing mode
  return (
    <div className={`todo-item ${todo.completed ? 'completed' : ''}`}>
      <input
        type="checkbox"
        checked={todo.completed}
        onChange={handleToggleComplete}
        className="checkbox"
      />
      <div className={`todo-content ${todo.completed ? 'completed' : ''}`}>
        {isEditing ? (
          // Display input field for editing when in editing mode
          <div>
            <input type="text" value={editedTodo} onChange={handleInputChange} />
            <button onClick={handleSaveEdit}>Save</button>
            <button onClick={handleCancelEdit}>Cancel</button>
          </div>
        ) : (
          // Display todo content and "Edit" button when not in editing mode
          <div>
            <span>{todo.content}</span>
            <button onClick={handleEditTodo} disabled={todo.completed}>
              Edit
            </button>
          </div>
        )}
      </div>
      <button onClick={handleDeleteTodo}>Delete</button>
    </div>
  );
};

export default TodoItem;
