import React from 'react';
import { useSelector } from 'react-redux';

const TodoCounter = () => {
  // Retrieve the 'list' property from the Redux state using the useSelector hook
  const todos = useSelector((state) => state.list);

  // Render a div showing the total number of todos
  return <div className="counter">Total Todos: {todos.length}</div>;
};

export default TodoCounter;
