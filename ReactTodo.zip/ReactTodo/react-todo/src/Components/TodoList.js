import React from 'react';
import { useSelector } from 'react-redux';
import TodoItem from './TodoItem';
import '../Style/TodoList.css';

const TodoList = () => {
  // Get the list of todos from the Redux store using the useSelector hook
  const todos = useSelector((state) => state.list);

  // Render the TodoList component
  return (
    <div className="todo-list">{/* Container div with the "todo-list" class */}
     {/* Map through each todo and render a TodoItem component */}
      {todos.map((todo, index) => (
        <TodoItem key={index} todo={todo} index={index} />
      ))}
    </div>
  );
};

export default TodoList;


