import { createStore } from 'redux';
import todosReducer from './Todos';

// Create a Redux store by passing the todosReducer to createStore
const store = createStore(todosReducer);

export default store;
