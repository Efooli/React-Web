// Define the initial state for todos
const initialTodoState = {
  list: [
    { content: "Content1", completed: false },
    { content: "Content2", completed: false },
  ],
};

// Define action types
export const ADD_TODO = 'ADD_TODO';
export const DELETE_TODO = 'DELETE_TODO';
export const EDIT_TODO = 'EDIT_TODO';
export const TOGGLE_TODO = 'TOGGLE_TODO';

// Action creator for adding a new todo
export const addTodo = (content) => ({
  type: ADD_TODO,
  payload: { content },
});

// Action creator for deleting a todo
export const deleteTodo = (index) => ({
  type: DELETE_TODO,
  payload: { index },
});

// Action creator for editing a todo
export const editTodo = (index, content) => ({
  type: EDIT_TODO,
  payload: { index, content },
});

// Action creator for toggling the completion status of a todo
export const toggleTodo = (index) => ({
  type: TOGGLE_TODO,
  payload: { index },
});

// Reducer function to handle todos based on dispatched actions
const todosReducer = (state = initialTodoState, action) => {
  switch (action.type) {
    case ADD_TODO:
      // Add a new todo to the list with the provided content
      return {
        ...state,
        list: [...state.list, { content: action.payload.content, completed: false }],
      };

    case DELETE_TODO:
      // Remove the todo at the specified index from the list
      return {
        ...state,
        list: state.list.filter((_, index) => index !== action.payload.index),
      };

    case EDIT_TODO:
      // Update the content of the todo at the specified index
      return {
        ...state,
        list: state.list.map((todo, index) =>
          index === action.payload.index ? { ...todo, content: action.payload.content } : todo
        ),
      };

    case TOGGLE_TODO:
      // Toggle the completion status of the todo at the specified index
      return {
        ...state,
        list: state.list.map((todo, index) =>
          index === action.payload.index ? { ...todo, completed: !todo.completed } : todo
        ),
      };

    default:
      // If no action type matches, return the current state
      return state;
  }
};

// Export the todosReducer as the default export
export default todosReducer;
