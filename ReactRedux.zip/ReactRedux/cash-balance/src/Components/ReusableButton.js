import React from 'react';
import { Button } from 'react-bootstrap';

// Functional component for rendering a reusable button
const ReusableButton = ({ onClick, label, color }) => {
  return (
    // JSX rendering of the Button component with variant, onClick, and label properties
    <Button variant={color} onClick={onClick}>
      {label}
    </Button>
  );
};

export default ReusableButton;

