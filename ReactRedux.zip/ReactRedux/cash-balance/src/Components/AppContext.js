import { createContext, useReducer } from 'react';

// Initial state for the app's global context
const initialState = {
  balance: 0,
};

// Reducer function to manage state changes based on dispatched actions
const reducer = (state, action) => {
  // Destructuring action for easier access
  const { type, payload } = action;

  // Handling different action types
  if (type === 'DEPOSIT') {
    // If Deposit button is clicked, increase balance by the deposited amount
    return { ...state, balance: state.balance + payload };
  }

  if (type === 'WITHDRAW') {
    // If Withdraw button is clicked, decrease balance by the withdrawn amount
    return { ...state, balance: state.balance - payload };
  }

  if (type === 'ADD_INTEREST') {
    // If Add Interest button is clicked, increase balance by 5%
    const interestAmount = state.balance * 0.05;
    return { ...state, balance: state.balance + interestAmount };
  }

  if (type === 'CHARGES') {
    // If Charges button is clicked, decrease balance by 15%
    const chargesAmount = state.balance * 0.15;
    return { ...state, balance: state.balance - chargesAmount };
  }

  // If an unknown action type is dispatched, return the current state
  return state;
};

// Creating the context and provider for the app
export const AppContext = createContext();

export const AppProvider = ({ children }) => {
  // useReducer to manage state and actions
  const [state, dispatch] = useReducer(reducer, initialState);

  return (
    // Provide the state and dispatch function to the context
    <AppContext.Provider value={{ ...state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};
