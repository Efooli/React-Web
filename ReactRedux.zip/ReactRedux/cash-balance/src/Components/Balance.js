import React, { useContext } from 'react';
import { AppContext } from './AppContext';

// Functional component to display the current balance
const Balance = () => {
  // Accessing the balance state from the global context using useContext hook
  const { balance } = useContext(AppContext);

  // Round the balance to two decimal places for display
  const roundedBalance = parseFloat(balance).toFixed(2);

  // JSX rendering to display the current balance in a paragraph element
  return (
    <div className="balance">
      <p>Balance: R{roundedBalance}</p>
    </div>
  );
};

export default Balance;
