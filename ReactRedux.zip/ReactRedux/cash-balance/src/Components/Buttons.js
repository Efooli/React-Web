import React, { useContext, useState } from 'react';
import ReusableButton from './ReusableButton'; 
import { AppContext } from './AppContext'; 
import { FormControl } from 'react-bootstrap'; 

// Functional component for rendering the buttons and input field
const Buttons = () => {
  const { dispatch } = useContext(AppContext); // Destructuring dispatch from the global context
  const [amount, setAmount] = useState(0); // State to track the input amount

  // Function to handle deposit action
  const handleDeposit = () => {
    const roundedAmount = parseFloat(amount).toFixed(2); // Round the input amount to 2 decimal places
    dispatch({ type: 'DEPOSIT', payload: parseFloat(roundedAmount) }); // Dispatching deposit action with the rounded amount
    setAmount(0); // Resetting the input amount after deposit
  };

  // Function to handle withdraw action
  const handleWithdraw = () => {
    const roundedAmount = parseFloat(amount).toFixed(2); // Round the input amount to 2 decimal places
    dispatch({ type: 'WITHDRAW', payload: parseFloat(roundedAmount) }); // Dispatching withdraw action with the rounded amount
    setAmount(0); // Resetting the input amount after withdrawal
  };

  // Function to handle add interest action
  const handleAddInterest = () => {
    const roundedInterest = (parseFloat(amount) * 0.05).toFixed(2); // Calculate interest and round to 2 decimal places
    dispatch({ type: 'ADD_INTEREST', payload: parseFloat(roundedInterest) }); // Dispatching add interest action
  };

  // Function to handle charges action
  const handleCharges = () => {
    const roundedCharges = (parseFloat(amount) * 0.15).toFixed(2); // Calculate charges and round to 2 decimal places
    dispatch({ type: 'CHARGES', payload: parseFloat(roundedCharges) }); // Dispatching charges action
  };

  // Styles for the buttons
  const buttonStyle = {
    width: '100px',
    height: '30px',
  };

  // Styles for the container holding the buttons and input field
  const containerStyle = {
    display: 'flex',
    flexDirection: 'row', // Horizontal alignment
    alignItems: 'center', // Center vertically
    justifyContent: 'center', // Center horizontally
    height: '20vh', // Full height of the viewport
  };

  // JSX rendering for the Buttons component
  return (
    <div style={containerStyle}>
      {/* Input field for entering the amount */}
      <FormControl
        type="number"
        placeholder="Enter amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        style={{ ...buttonStyle, marginRight: '10px' }} 
      />
      {/* ReusableButton component */}
      <ReusableButton onClick={handleDeposit} label="Deposit" color="success" style={buttonStyle} />
      <ReusableButton onClick={handleWithdraw} label="Withdraw" color="danger" style={buttonStyle} />
      <ReusableButton onClick={handleAddInterest} label="Add Interest" color="primary" style={buttonStyle} />
      <ReusableButton onClick={handleCharges} label="Charges" color="warning" style={buttonStyle} />
    </div>
  );
};

export default Buttons;
