import React from 'react';
import Balance from './Components/Balance';
import Buttons from './Components/Buttons';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Cash Balance Manager</h1>
      <Balance />
      <Buttons />
    </div>
  );
}

export default App;
