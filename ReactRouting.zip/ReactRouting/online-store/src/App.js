// App.js
import React from "react";
import { Routes, Route, Link, useNavigate } from "react-router-dom";
import NavigationMenu from "./Components/NavigationMenu";
import Home from "./Components/Home";
import About from "./Components/About";
import Products from "./Components/Products";


function App() {
  return (
    <div className="App">
      <NavigationMenu />
      <Routes>
        <Route
          path="/"
          element={
            <>
              <HomeLink />
              <Home />
            </>
          }
        />
        <Route path="/products" element={<Products />} />
        <Route path="/about" element={<About />} />
      </Routes>
      
    </div>
  );
}

const HomeLink = () => {
  const navigate = useNavigate();

  return (
    <div>
      <Link to="/" onClick={() => navigate("/")}></Link>
    </div>
  );
};

export default App;
