import React, { useState } from 'react';
import '../Style/Home.css'; // Import CSS file for styling

function Home() {
  // State for user name and login status
  const [userName, setUserName] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Function to handle user login
  const handleLogin = () => {
    // Check if the input field is not empty
    if (userName.trim() !== '') {
      // Set isLoggedIn to true if the user name is provided
      setIsLoggedIn(true);
    }
  };

  // Function to handle user logout
  const handleLogout = () => {
    // Set isLoggedIn to false and clear the user name
    setIsLoggedIn(false);
    setUserName('');
  };

  return (
    <div className="home-container"> {/* Add a class to center the content */}
      {isLoggedIn ? (
        <div>
          {/* Display welcome message and logout button if user is logged in */}
          <h1>Welcome {userName}!</h1>
          <button className="logout-button" onClick={handleLogout}>Logout</button> {/* Added a class for styling */}
        </div>
      ) : (
        <div>
          {/* Display input field and login button if user is not logged in */}
          <input
            type="text"
            placeholder="Enter your name"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
          />
          <button className="login-button" onClick={handleLogin}>Login</button>
        </div>
      )}
    </div>
  );
}

export default Home;

