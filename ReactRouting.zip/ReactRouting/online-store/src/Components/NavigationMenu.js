import React from 'react';
import { Link } from 'react-router-dom';
import '../Style/NaviMenu.css'; // Import CSS file for styling

function NavigationMenu() {
  return (
    <nav>
      <ul>
        {/* Navigation links using React Router */}
        <Link to="/">Home</Link>
        <br/>
        <Link to="/products">Products</Link>
        <br/>
        <Link to="/about">About</Link>
      </ul>
    </nav>
  );
}

export default NavigationMenu;
