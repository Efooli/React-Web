// Import the action type constants from the Action file
import { ADD_TO_CART, UPDATE_QUANTITY } from "./Action";

// Initial state of the Redux store
const initialState = {
  cart: [], // Initially, the cart is an empty array
  total: 0,
};

// Reducer function to handle state updates based on dispatched actions
const rootReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_TO_CART:
      return {
        ...state,
        cart: [...state.cart, action.payload],
        total: state.total + action.payload.price,
      };
    case UPDATE_QUANTITY:
      const { productId, quantityChange } = action.payload;
      // Find the product in the cart
      const updatedCart = state.cart
        .map(item => {
          if (item.productId === productId) {
            // Update the quantity
            const newQuantity = item.quantity + quantityChange;
            // Ensure the quantity is at least 1
            const updatedQuantity = Math.max(newQuantity, 0);
            // Update the price accordingly
            const updatedPrice = item.price * updatedQuantity;

            return { ...item, quantity: updatedQuantity, totalPrice: updatedPrice };
          }
          return item;
        })
        .filter(item => item.quantity > 0); // Remove items with quantity 0

      return {
        ...state,
        cart: updatedCart,
        total: updatedCart.reduce((total, item) => total + item.totalPrice, 0),
      };
    default:
      return state;
  }
};

export default rootReducer;
