// Action type constant for adding an item to the cart
export const ADD_TO_CART = "ADD_TO_CART";
// Action type constant for updating the quantity of an item in the cart
export const UPDATE_QUANTITY = "UPDATE_QUANTITY";
// Action type constant for deleting an item from the cart
export const DELETE_FROM_CART = "DELETE_FROM_CART";

// Action creator function to create an action for adding an item to the cart
export const addToCart = (productId, price, image, title) => ({
  type: ADD_TO_CART,
  payload: {
    productId,
    price,
    image,
    title,
    quantity: 1, // Set initial quantity to 1 when adding to the cart
  },
});


// Action creator function to update the quantity of an item in the cart
export const updateQuantity = (productId, quantityChange) => ({
  type: UPDATE_QUANTITY,
  payload: {
    productId,
    quantityChange,
  },
});


// Action creator function to create an action for deleting an item from the cart
export const deleteFromCart = (productId) => ({
  type: DELETE_FROM_CART,
  payload: {
    productId,
  },
});
