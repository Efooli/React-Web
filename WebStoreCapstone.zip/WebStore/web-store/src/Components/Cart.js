import React, { useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Modal, Button } from "react-bootstrap";
import { updateQuantity } from "../Redux/Action";
import "../Style/Cart.css";

const Cart = () => {
  const dispatch = useDispatch(); // Initialize dispatch function to send actions to the store

  const cart = useSelector((state) => state.cart); // Get cart state from the Redux store
  const [shipmentMethod, setShipmentMethod] = useState("standard"); // State for selected shipment method
  const [showHelpModal, setShowHelpModal] = useState(false); // State for Help modal visibility

  // Calculate total price of items in the cart
  const calculateTotal = () => {
    let total = cart.reduce((total, item) => total + item.price * item.quantity, 0);
    if (shipmentMethod === "express") {
      total += 100;
    }
    return total.toFixed(2);
  };

  // Handle shipment method change
  const handleShipmentChange = (method) => {
    setShipmentMethod(method);
  };

  // Toggle Help modal visibility
  const toggleHelpModal = () => {
    setShowHelpModal(!showHelpModal);
  };

  // Handle incrementing the quantity of a product
  const handleIncrement = (productId) => {
    dispatch(updateQuantity(productId, 1));
  };

  // Handle decrementing the quantity of a product
  const handleDecrement = (productId) => {
    dispatch(updateQuantity(productId, -1));
  };

  return (
    <div className="container">
      <h2>Your Cart</h2>
      {cart.length === 0 ? ( // Display "Cart Empty" message if the cart is empty
        <p>Cart Empty</p>
      ) : (
        <>
          <div className="cart-items">
            {cart.map((item) => (
              <div key={item.productId} className="cart-item">
                <img src={item.image} alt={item.title} className="cart-item-image" />
                <div className="cart-item-details">
                  <p>{item.title}</p>
                  <p>Price: R{item.price.toFixed(2)}</p>
                  <div className="quantity-control">
                    <button className="quantity-btn" onClick={() => handleDecrement(item.productId)}>-</button>
                    <span className="quantity">{item.quantity}</span>
                    <button className="quantity-btn" onClick={() => handleIncrement(item.productId)}>+</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="total-box">Total: R{calculateTotal()}</div>
          <div className="shipment-options">
            <p>Please choose your shipment method:</p>
            <label>
              <input
                type="radio"
                value="standard"
                checked={shipmentMethod === "standard"}
                onChange={() => handleShipmentChange("standard")}
              />
              Standard (5-7 days)
            </label>
            <br />
            <label>
              <input
                type="radio"
                value="express"
                checked={shipmentMethod === "express"}
                onChange={() => handleShipmentChange("express")}
              />
              Express (2-3 days) - Additional R100
            </label>
          </div>
          <button className="btn btn-info mt-3" onClick={toggleHelpModal}>Help</button>
        </>
      )}
      {/* Help Modal */}
      <Modal show={showHelpModal} onHide={toggleHelpModal}>
        <Modal.Header closeButton>
          <Modal.Title>Shipping Help</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>For shipping options:</p>
          <p>Standard (5-7 working days) - No additional cost, pick up at your nearest store</p>
          <p>Express (2-3 working days) - Additional R100, express shipping is to your door</p>
          <p>For any queries, please contact us at 0659189805</p>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={toggleHelpModal}>Close</Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default Cart;
