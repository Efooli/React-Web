import React from 'react';
import './MediaList.css';

const MediaList = ({ searchResults, onAddToFavorites, setFavorites }) => {
  // Check if searchResults is empty or not an array
  if (!searchResults || (!Array.isArray(searchResults) && searchResults.length === undefined)) {
    return <p>No results available</p>;
  }

  // Flatten the searchResults array if it's nested
  const flattenedResults = Array.isArray(searchResults) ? searchResults.flat() : searchResults;

  // Function to handle adding an item to favorites
  const handleAddToFavorites = async (item) => {
    try {
      // Make a POST request to add the item to favorites
      const response = await fetch('http://localhost:3001/api/favorites', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiUmlhbGl2aHV3YSBEemlhbHdhIn0.RkKgVXRFx9TEiiCN6Wvf-IJcmkTAZS79E17SNnc1B3I', // Replace with your actual token
        },
        body: JSON.stringify(item),
      });

      // Check if the request was successful
      if (!response.ok) {
        throw new Error(`Failed to add to favorites: ${response.status} ${response.statusText}`);
      }

      // Parse the response data and update the favorites state
      const data = await response.json();
      setFavorites((prevFavorites) => [...prevFavorites, data]);
    } catch (error) {
      // Handle errors during the request
      console.error('Error adding to favorites:', error.message);
    }
  };

  // Render the MediaList component
  return (
    <div>
      <h2>Search Results</h2>
      <ul className="search-results-list">
        {/* Map through flattenedResults and display each result */}
        {flattenedResults.map((result, index) => (
          <li key={`${result.name}-${index}`} className="search-results-item">
      
            {result.cover && (
              <img src={result.cover.replace('http://', 'https://')} alt={result.name} />
            )}

            {/* Display media information and Add to Favorites button */}
            <div>
              <h3>{result.name}</h3>
              <p>Artist: {result.artistName}</p>
              <p>Release Date: {result.releaseDate}</p>
              <button onClick={() => handleAddToFavorites(result)}>Add to Favorites</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MediaList;
