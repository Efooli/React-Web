import React, { useState, useEffect, useCallback } from 'react';
import './Searchbar.css';

const SearchBar = ({ onSearch, onSelectType }) => {
  // State to manage the search term entered by the user
  const [searchTerm, setSearchTerm] = useState('');
  // State to manage the selected media type
  const [selectedMediaType, setSelectedMediaType] = useState('music');

  // Callback function to handle the search operation
  const handleSearch = useCallback(async () => {
    try {
      // Make a GET request to fetch search results based on the entered search term and selected media type
      const response = await fetch(`http://localhost:3001/api/music?term=${searchTerm}&mediaType=${selectedMediaType}`, {
        headers: {
          'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiUmlhbGl2aHV3YSBEemlhbHdhIn0.RkKgVXRFx9TEiiCN6Wvf-IJcmkTAZS79E17SNnc1B3I',
        },
      });

      // Check if the request was successful
      if (!response.ok) {
        throw new Error(`Failed to fetch search results: ${response.status} ${response.statusText}`);
      }

      // Parse the response data as JSON
      const data = await response.json();

      // Pass the fetched data to the parent component
      onSearch(data);
    } catch (error) {
      // Handle errors during the request
      console.error('Error fetching search results:', error.message);
    }
  }, [searchTerm, selectedMediaType, onSearch]);

  // Effect to trigger the search operation when the search term changes
  useEffect(() => {
    if (searchTerm) {
      handleSearch();
    }
  }, [searchTerm, handleSearch]);

  // Render the search bar UI
  return (
    <div className="search-bar-container">
      {/* Input field to enter the search term */}
      <input
        type="text"
        placeholder="Enter search term"
        className="search-input"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      {/* Dropdown to select the media type */}
      <select title="Select media type" onChange={(e) => setSelectedMediaType(e.target.value)} value={selectedMediaType}>
        <option value="all">All</option>
        <option value="movie">Movie</option>
        <option value="podcast">Podcast</option>
        <option value="music">Music</option>
        <option value="musicVideo">Videos</option>
      </select>
      {/* Button to initiate the search */}
      <button className="search-button" onClick={handleSearch}>
        Enter
      </button>
    </div>
  );
};

export default SearchBar;
