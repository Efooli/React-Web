import React, { useEffect } from 'react';
import './FavList.css';

const FavoritesList = ({ favorites, setFavorites }) => {
  useEffect(() => {
    // You can add any side effect logic related to favorites or remove the useEffect if unnecessary
  }, [favorites]);

  if (!favorites || favorites.length === 0) {
    return <p>No favorites available</p>;
  }

  const handleRemoveFromFavorites = async (favoriteToRemove) => {
    try {
      const response = await fetch(`http://localhost:3001/api/favorites/${favoriteToRemove.id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJuYW1lIjoiUmlhbGl2aHV3YSBEemlhbHdhIn0.RkKgVXRFx9TEiiCN6Wvf-IJcmkTAZS79E17SNnc1B3I',
        },
      });

      if (!response.ok) {
        throw new Error(`Failed to remove from favorites: ${response.status} ${response.statusText}`);
      }

      setFavorites((prevFavorites) =>
        prevFavorites.filter((favorite) => favorite.id !== favoriteToRemove.id)
      );
    } catch (error) {
      console.error('Error removing from favorites:', error.message);
    }
  };

  return (
    <div>
      <h2>Favorites</h2>
      <div className="favorites-container">
        {favorites.map((favorite, index) => (
          <div
            key={`${favorite.name}-${index}`}
            className="favorites-card"
          >
            <img src={favorite.cover} alt={favorite.name} />
            <div>
              <h3>{favorite.name}</h3>
              <p>Artist: {favorite.artistName}</p>
              <p>Release Date: {favorite.releaseDate}</p>
              <button onClick={() => handleRemoveFromFavorites(favorite)}>
                Remove from Favorites
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FavoritesList;
