import React, { useState } from 'react';
import SearchBar from './Components/SearchBar/Searchbar';
import MediaList from './Components/MediaList/MediaList';
import FavoritesList from './Components/FavouriteList/FavouriteList';

const App = () => {
  // State to manage the search results
  const [searchResults, setSearchResults] = useState([]);

  // State to manage the favorite items
  const [favorites, setFavorites] = useState([]);

  // Callback function to handle search results
  const handleSearch = (data) => {
    setSearchResults(data);
  };

  // Callback function to handle the selected media type
  const handleSelectType = (selectedType) => {
    console.log(`Selected media type: ${selectedType}`);
  };

  // Render the main App component
  return (
    <div>
      {/* SearchBar component with callbacks for search and media type selection */}
      <SearchBar onSearch={handleSearch} onSelectType={handleSelectType} setFavorites={setFavorites} />

      {/* MediaList component displaying search results with the ability to add to favorites */}
      <MediaList searchResults={searchResults} setFavorites={setFavorites} />

      {/* FavoritesList component displaying favorite items with the ability to remove from favorites */}
      <FavoritesList favorites={favorites} setFavorites={setFavorites} />
    </div>
  );
};

export default App;
