import React from 'react';

// Functional component to display the total price
const TotalPrice = ({ totalPrice }) => {
  return (
    // Fixed position div at the top-right corner for displaying total price
    <div style={{ position: 'fixed', top: 50, right: 10, backgroundColor: 'white', padding: 10, border: '1px solid #ccc' }}>
      {/* Heading displaying the total price */}
      <h2>Total price: R{totalPrice}</h2>
    </div>
  );
};

export default TotalPrice;


