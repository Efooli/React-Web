import React from "react";
import { useFormik } from "formik";

// Login component
const Login = () => {
  // Define initial form values
  const initialValues = {
    email: "",
    password: "",
  };

  // Define validation function
  const validateForm = (values) => {
    const errors = {};

    // Validate email
    if (!values.email) {
      errors.email = "Email is required";
    }

    // Validate password
    if (!values.password) {
      errors.password = "Password is required";
    } else if (values.password.length < 8) {
      errors.password = "Password must be at least 8 characters long";
    }

    return errors;
  };

  // Define form submission function
  const handleSubmit = (values, { setSubmitting }) => {
    // Handle form submission, e.g., send data to server

    // Reset form submission state
    setSubmitting(false);
  };

  // Use the useFormik hook
  const formik = useFormik({
    initialValues,
    validate: validateForm,
    onSubmit: handleSubmit,
  });

  return (
    <div>
      <h2>Login</h2>

      {/* Form */}
      <form onSubmit={formik.handleSubmit}>
        {/* Email field */}
        <div>
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formik.values.email}
            onChange={formik.handleChange}
          />
          {formik.errors.email && <div>{formik.errors.email}</div>}
        </div>

        {/* Password field */}
        <div>
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formik.values.password}
            onChange={formik.handleChange}
          />
          {formik.errors.password && <div>{formik.errors.password}</div>}
        </div>

        {/* Submit button */}
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default Login;
