import React, { useState } from "react";
import { Card, Button, Dropdown } from "react-bootstrap";
import TotalPrice from "./TotalPrice";
import "../Style/Products.css";

const Products = () => {
  // State for selected colors and total price
  const [selectedColors, setSelectedColors] = useState("");
  const [totalPrice, setTotalPrice] = useState(0);

  // Function to handle color selection for a product
  const handleColorSelect = (productId, color) => {
    // Update selected colors state using the previous state
    setSelectedColors((prevColors) => ({
      ...prevColors,
      [productId]: color,
    }));
  };

  // Function to handle buy button click
  const handleBuyClick = (price) => {
    // Update total price state by adding the price of the purchased product
    setTotalPrice((prevTotal) => prevTotal + price);
  };

  // Data for product information
  const productsData = [
    {
      id: 1,
      title: "iPhone 12",
      description: "A powerful phone with 5G capabilities",
      price: 14000,
      colors: ["Silver", "Space Gray", "Gold"],
      image: "/Images/Iphone12.jpg",
    },
    {
      id: 2,
      title: "iPhone SE",
      description: "Compact yet powerful",
      price: 7999,
      colors: ["Black", "White", "Product(RED)"],
      image: "/Images/IphoneSE.jpg",
    },
    {
      id: 3,
      title: "iPhone 11",
      description: "Dual-camera system and all-day battery life",
      price: 10999,
      colors: ["Green", "Purple", "Yellow"],
      image: "/Images/Iphone11.jpg",
    },
    {
      id: 4,
      title: "iPhone XR",
      description: "Liquid Retina HD display and A12 Bionic chip",
      price: 8999,
      colors: ["Blue", "Coral", "Red"],
      image: "/Images/IphoneXR.jpg",
    },
    {
      id: 5,
      title: "iPhone 8",
      description: "Touch ID and wireless charging",
      price: 9999,
      colors: ["Rose Gold", "Jet Black", "Silver"],
      image: "/Images/iphone8.jpg",
    },
    {
      id: 6,
      title: "iPhone 12 Pro",
      description: "Pro camera system for stunning photos and videos",
      price: 15999,
      colors: ["Pacific Blue", "Graphite", "Gold"],
      image: "/Images/Iphone12Pro.jpg",
    },
    {
      id: 7,
      title: "iPhone X",
      description: "Super Retina display and Face ID",
      price: 8999,
      colors: ["Silver", "Space Gray", "Rose Gold"],
      image: "/Images/IphoneX.png",
    },
    {
      id: 8,
      title: "iPhone 11 Pro",
      description: "Triple-camera system and Super Retina XDR display",
      price: 12999,
      colors: ["Midnight Green", "Silver", "Gold"],
      image: "/Images/Iphone11Pro.jpg",
    },
    {
      id: 9,
      title: "iPhone XS",
      description: "A12 Bionic chip and Dual-camera system",
      price: 10999,
      colors: ["Silver", "Space Gray", "Gold"],
      image: "/Images/IphoneXS.jpeg",
    },
    {
      id: 10,
      title: "iPhone 12 Mini",
      description: "Compact size with A14 Bionic chip",
      price: 12999,
      colors: ["Blue", "Green", "White"],
      image: "/Images/Iphone12Mini.jpg",
    },
  ];

  return (
    <div className="container mt-4 position-relative">
      <div className="row row-cols-1 row-cols-md-3 g-4">
        {/* Map through productsData array and render each product */}
        {productsData.map((product) => (
          <div key={product.id} className="col">
            {/* Bootstrap Card component for each product */}
            <Card className="h-100">
              {/* Product image */}
              
              <Card.Img
                variant="top"
                src={process.env.PUBLIC_URL + product.image}
                className="img-fluid product-image"
              />
              <Card.Body>
                {/* Product title, description, and price */}
                <Card.Title>{product.title}</Card.Title>
                <Card.Text>{product.description}</Card.Text>
                <Card.Text>Price: R{product.price}</Card.Text>

                {/* Bootstrap Dropdown for color selection */}
                <Dropdown
                  onSelect={(color) => handleColorSelect(product.id, color)}
                >
                  <Dropdown.Toggle
                    variant={
                      selectedColors[product.id]
                        ? `info btn-${selectedColors[product.id]}`
                        : "info"
                    }
                    id={`dropdown-${product.id}`}
                  >
                    {selectedColors[product.id] || "Select Color"}
                  </Dropdown.Toggle>

                  {/* Dropdown menu with color options */}
                  <Dropdown.Menu>
                    {product.colors.map((color) => (
                      <Dropdown.Item key={color} eventKey={color}>
                        {color}
                      </Dropdown.Item>
                    ))}
                  </Dropdown.Menu>
                </Dropdown>

                {/* Buy button with onClick handler */}
                <Button
                  variant="primary"
                  className="mt-3"
                  onClick={() => handleBuyClick(product.price)}
                >
                  Buy
                </Button>
              </Card.Body>
            </Card>
          </div>
        ))}
      </div>
      {/* Display TotalPrice component if the total price is greater than 0 */}
  
    {totalPrice > 0 && <TotalPrice totalPrice={totalPrice} />}
   
    </div>
  );
};

export default Products;
