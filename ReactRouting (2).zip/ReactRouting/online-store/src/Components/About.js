import React from 'react';
import { Figure } from 'react-bootstrap';
import '../Style/About.css'; // Import CSS file for styling

const About = () => {
  return (
    <div className="container mt-4">
      <div className="image-container">
        {/* Store Logo Section */}
        <Figure>
          <Figure.Image
            className="store-logo"
            width={100}
            height={100}
            alt="Store Logo"
            src="./Images/Logo.png"
          />
          <Figure.Caption>
            <p>
              {/* Store Introduction */}
              Welcome to our exclusive iPhone Store, where cutting-edge
              technology meets style! Discover the latest and greatest from
              Apple's iconic iPhone lineup. Immerse yourself in the world of
              innovation with powerful processors, stunning displays, and
              exceptional camera systems. Whether you're drawn to the sleek
              design of the iPhone 12 or the compact brilliance of the iPhone
              SE, we have the perfect device to suit your lifestyle. Elevate
              your mobile experience and stay ahead with the most sought-after
              iPhones. Explore our collection today and embrace the future of
              mobile technology!
            </p>
          </Figure.Caption>
        </Figure>

        {/* Store Image 1 Section */}
        <Figure>
          <Figure.Image
            className="store-image"
            alt="Store Image 1"
            src="https://via.placeholder.com/400x200?text=Store+Image+1"
          />
          <Figure.Caption>
            <p>Store Image 1</p>
          </Figure.Caption>
        </Figure>
        <br />

        {/* Store Image 2 Section */}
        <Figure>
          <Figure.Image
            className="store-image"
            alt="Store Image 2"
            src="https://via.placeholder.com/400x200?text=Store+Image+2"
          />
          <Figure.Caption>
            <p> Store Image 2</p>
          </Figure.Caption>
        </Figure>
      </div>

      {/* Contact Section */}
      <div className="contact-section">
        <h2>Contact Us</h2>
        <p>Feel free to reach out to us for any inquiries or assistance.</p>

        {/* Placeholder for contact information */}
        <p>Email: istore@gmail.com</p>
        <p>Phone: (123) 456-7890</p>
        <p>Address: 123 Bree Street, Cape Town</p>
      </div>
    </div>
  );
};

export default About;

